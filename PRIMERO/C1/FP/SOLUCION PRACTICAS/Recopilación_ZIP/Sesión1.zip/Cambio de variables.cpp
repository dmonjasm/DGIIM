/*Programa que intercambie los contenidos de dos variables enteras
Se necesitan: dos variables
            edad_pedro   edad_juan
Se obtiene el valor d las variables intercambiados
*/

#include <iostream>   //Declara la biblioteca iostream	
#include <cmath>      //Declara la biblioteca de operaciones matematicas

using namespace std;

int main() {
	double edad_pedro;
	double edad_juan;
	double a;
	
	
	cout << "Introduza la edad de Pedro: ";
	cin >> edad_pedro;
	cout << "Introduzca la edad de Juan: ";
	cin >> edad_juan;
	
	a = edad_pedro;
	edad_pedro = edad_juan;
	edad_juan = a;

	

	cout << "\nLa edad de Pedro es " << edad_pedro << " y la edad de Juan es " << edad_juan << "\n";
	
	system("pause");
}
	
	
