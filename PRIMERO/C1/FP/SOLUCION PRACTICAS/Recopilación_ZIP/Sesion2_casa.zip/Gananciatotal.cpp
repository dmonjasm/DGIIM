/*Programa para hallar lo que gana un dise�ador y tres fabricantes al vender un producto 
teniendo en cuenta que el dise�ador gana el doble que cada uno de los fabricantes dada la ganancia total
de la venta de los productos.
Se necesita: ganancia total
    				gantot
Se obtiene: lo que gana cada trabajador y el dise�ador
					trabj1 trabj2 						dis
*/

#include <iostream>	//Se inlcuye la biblioteca iostream
#include <cmath>     //Se incluye la bilbioteca de operaciones matem�ticas cmath

using namespace std;

int main() {
	double trabj1;			//Declara las variables que se van a 
	double dis;				//utilizar en el algoritmo y la que 
	double gantot;			//se le va a pedir al usuario
	
	cout << "Introduzca las ganancias totales obtenidas por la venta del producto: ";		//Pide al usuario que introduzca el valor de la variable gantot
	cin >> gantot;
	
	trabj1 = gantot / 4;			//Declaro los algoritmos a partir de los cuales
	dis = trabj1 * 2;				//se calculara el dinero que gana los trabajadores y el dise�ador
	
	cout << "El trabajador 1 gana, " << trabj1 << " , el trabajador 2 gana, " << trabj1 << " y el disenador gana, " << dis << "\n";		//Anuncia el resultado al usuario
	
	system("pause");
}
