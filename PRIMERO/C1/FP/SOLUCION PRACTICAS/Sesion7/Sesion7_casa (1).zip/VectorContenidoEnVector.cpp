/*Programa que dados dos vectores de enteros devuelva las veces que el segundo
aparece en el primero.
*/

#include <iostream>
#include <cmath>

using namespace std;

int main() {
   const int LONGITUD = 200;
   int vector1[LONGITUD], vector2[LONGITUD], vector3[LONGITUD];
   int amplitud1, amplitud2, minimo, contador;
   bool contenido;
   
   cout << "Introduzca la amplitud del vector 1: ";
   cin >> amplitud1;
   cout << "\nIntroduzca la amplitud del vector 2: ";
   cin >> amplitud2;
   
   for (int i = 0; i < amplitud1; i++){
      cout << "\nIntroduzca los valores del vector 1:";
      cin >> vector1[i];
   }
   
   for (int j = 0; j < amplitud2; j++){
      cout << "\nIntroduzca los valores del vector 2: ";
      cin >> vector2[j];
   }
   
   
      
   

