/**
 * @file Kmer.cpp
 * @author MP
 */
