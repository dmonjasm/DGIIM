/** 
 * @file SecuenciasKmer.cpp
 * @author MP
*/

#include <iostream>
#include <fstream>
#include <cmath>

#include "Kmer.h"
#include "SecuenciasKmer.h"

using namespace std;



double SecuenciasKmer::distancia(const SecuenciasKmer & d) const {
    long posB;
    long posA = 0;
    double dist = 0.0;

    for (long i = 0; i < this->getSize(); ++i) {
        posB = d.findKmer (getPosicion(i).getCadena());
        if (posB < 0) {
            posB = getSize();
        }

        dist += abs(posA - posB);
        posA++;
    }
    return dist / (getSize() * getSize()); 
}