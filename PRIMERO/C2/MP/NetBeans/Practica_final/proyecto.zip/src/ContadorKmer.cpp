/** 
 * @file ContadorKmer.cpp
 * @author DECSAI
*/
