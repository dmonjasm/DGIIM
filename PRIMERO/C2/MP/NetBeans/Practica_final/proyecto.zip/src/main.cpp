/**
 * @file main.cpp
 * @author MP
 */
#include <iostream>
#include <string>
#include "Kmer.h"
#include "SecuenciasKmer.h"
#include "ContadorKmer.h"

using namespace std;

void mensajeError();

const string ContadorKmer::INI_VALIDOS = "_acgt";
const int ContadorKmer::INI_K=5;


int main(int narg, char *args[]) {
    return 0;
}

void mensajeError() {
    cerr << "ERROR en la llamada" << endl;
    cerr << "   kmer [-l f.kmer fa.dna [fn.dna]] [-c f.dna fa.kmer [fn.kmer]]"<<endl;
    exit(1); 
}

