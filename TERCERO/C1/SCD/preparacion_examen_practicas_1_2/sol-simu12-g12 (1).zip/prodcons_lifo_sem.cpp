// -----------------------------------------------------------------------------------
//
// Prácticas SCD 20-21 GIM-GIADE (profesor: Carlos Ureña)
// Simulacro de examen (Práctica 1)
// Archivo: 'prodcons_lifo_sem.cpp'
// Solución con semáforos al prpblema del productor-consumidor con buffer intermedio
// (con un productor y un consumidor, opción LIFO)
// 
// Enunciado en el simulacro:
//
//  1. 
//     Sube a la tarea un archivo llamado exactamente 'prodcons_lifo_sem.cpp' con tu solución 
//     LIFO al problema de un productor y un consumidor, con buffer intermedio, usando semáforos. 
//     Ten en cuenta que los semáforos usados sean estrictamente los necesarios.
//
// -----------------------------------------------------------------------------------
    

#include <iostream>
#include <cassert>
#include <thread>
#include <mutex>
#include <random>
#include "Semaphore.h"

using namespace std ;
using namespace SEM ;

//**********************************************************************
// variables compartidas, comunes a las dos soluciones (fifo y lifo)

const unsigned 
   num_items      = 40 ,         // número de items
	tam_vector     = 10 ;         // tamaño del buffer

unsigned 
   primera_libre  = 0 ,          // índice de la primera entrada libre del vector
   buffer[tam_vector] ,          // buffer intermedio (compartido)
   cont_prod[num_items] = { 0 }, // contadores de verificación: por cada item, número de veces producido (debe ser 1 al final)
   cont_cons[num_items] = { 0 }; // contadores de verificación: por cada ítem, número de veces consumido (debe ser 1 al final)

Semaphore 
   puede_escribir = tam_vector, // semáforo compartido ( valor == tam_vec - #escrituras + #lecturas > 0 )
	puede_leer     = 0,          // semáforo compartido ( valor == #escrituras - #lecturas > 0 )
   mutex_buffer   = 1,          // semáforo para EM en los accesos al buffer usando 'primera_libre'
   mutex_cout     = 1 ;         // semáforo para EM al ejecutar 'cout << ....'


//**********************************************************************
// plantilla de función para generar un entero aleatorio uniformemente
// distribuido entre dos valores enteros, ambos incluidos
// (ambos tienen que ser dos constantes, conocidas en tiempo de compilación)
//----------------------------------------------------------------------

template< int min, int max > int aleatorio()
{
  static default_random_engine generador( (random_device())() );
  static uniform_int_distribution<int> distribucion_uniforme( min, max ) ;
  return distribucion_uniforme( generador );
}
//----------------------------------------------------------------------

unsigned producir_dato()
{
   static int contador = 0 ;
   this_thread::sleep_for( chrono::milliseconds( aleatorio<20,100>() ));
   sem_wait( mutex_cout );
      cout << "producido: " << contador << endl << flush ;
   sem_signal( mutex_cout );
   cont_prod[contador] ++ ;
   return contador++ ;
}
//----------------------------------------------------------------------

void consumir_dato( unsigned dato )
{
   assert( dato < num_items );
   cont_cons[dato] ++ ;
   this_thread::sleep_for( chrono::milliseconds( aleatorio<20,100>() ));
   sem_wait( mutex_cout );
      cout << "                  consumido: " << dato << endl ;
   sem_signal( mutex_cout );
}
//----------------------------------------------------------------------

void test_contadores()
{
   bool ok = true ;
   cout << "comprobando contadores ...." ;
   for( unsigned i = 0 ; i < num_items ; i++ )
   {  if ( cont_prod[i] != 1 )
      {  cout << "error: valor " << i << " producido " << cont_prod[i] << " veces." << endl ;
         ok = false ;
      }
      if ( cont_cons[i] != 1 )
      {  cout << "error: valor " << i << " consumido " << cont_cons[i] << " veces" << endl ;
         ok = false ;
      }
   }
   if (ok)
      cout << endl << flush << "solución (aparentemente) correcta." << endl << flush ;
}

//----------------------------------------------------------------------

void  funcion_hebra_productora(  )
{
   for( unsigned i = 0 ; i < num_items ; i++ )
   {
      unsigned dato = producir_dato() ;
      sem_wait( puede_escribir ) ;
      sem_wait( mutex_buffer );
         buffer[primera_libre] = dato ;
         primera_libre = primera_libre +1 ;
      sem_signal( mutex_buffer );
      sem_signal( puede_leer ) ;
   }
}

//----------------------------------------------------------------------

void funcion_hebra_consumidora(  )
{
   for( unsigned i = 0 ; i < num_items ; i++ )
   {
      unsigned  dato ;
      sem_wait( puede_leer );
      sem_wait( mutex_buffer );
         primera_libre = primera_libre - 1 ;
         dato = buffer[primera_libre]  ;
      sem_signal( mutex_buffer );
      sem_signal( puede_escribir ) ;
      consumir_dato( dato ) ;
    }
}
//----------------------------------------------------------------------

int main()
{
   cout << "-----------------------------------------------------------" << endl
        << "Problema de los 1 prod - 1 cons con buffer (solución LIFO)." << endl
        << "-----------------------------------------------------------" << endl
        << flush ;

   thread hebra_productora ( funcion_hebra_productora ),
          hebra_consumidora( funcion_hebra_consumidora );

   hebra_productora.join() ;
   hebra_consumidora.join() ;

   test_contadores();
}
//----------------------------------------------------------------------

