// -----------------------------------------------------------------------------------
//
// Prácticas SCD 20-21 GIM-GIADE (profesor: Carlos Ureña)
// Simulacro de examen (Práctica 1)
// Archivo: 'prodcons_lifo_sem.cpp'
// Solución con semáforos al prpblema del productor-consumidor con buffer intermedio
// (con un productor y un consumidor, opción FIFO)
//
// Enunciado en el simulacro:
//
//  1.
//     Sube a la tarea un archivo llamado exactamente 'prodcons_fifo_sem.cpp' con tu solución
//     LIFO al problema de un productor y un consumidor, con buffer intermedio, usando semáforos.
//     Ten en cuenta que los semáforos usados sean estrictamente los necesarios.
//
// -----------------------------------------------------------------------------------


#include <iostream>
#include <cassert>
#include <thread>
#include <mutex>
#include <random>
#include "Semaphore.h"

using namespace std ;
using namespace SEM ;

//**********************************************************************
// variables compartidas, comunes a las dos soluciones (fifo y lifo)

const int num_items      = 40 ,        // número de items a producir/consumir
	       tam_vector     = 10 ;        // tamaño del buffer
Semaphore puede_escribir = tam_vector, // semáforo compartido ( tam_vector - #insertados + #leídos )
	       puede_leer     = 0,          // semáforo compartido ( #insertados - #leídos )
          mutex_cout     = 1;          // semáforo para EM en las escrituras en pantalla con 'cout'
int       buffer[tam_vector] ;         // buffer intermedio (compartido)
unsigned  cont_prod[num_items] = {0},  // contadores de verificación: producidos
          cont_cons[num_items] = {0},  // contadores de verificación: consumidos
          contador             = 0,    // siguiente dato a producir en 'producir_dato'
          primera_libre        = 0,    // índice de la primera celda libre en el buffer
          primera_ocupada      = 0 ;   // índice de la primera celda ocupada en el buffer


//**********************************************************************
// plantilla de función para generar un entero aleatorio uniformemente
// distribuido entre dos valores enteros, ambos incluidos
// (ambos tienen que ser dos constantes, conocidas en tiempo de compilación)
//----------------------------------------------------------------------

template< int min, int max > int aleatorio()
{
  static default_random_engine generador( (random_device())() );
  static uniform_int_distribution<int> distribucion_uniforme( min, max ) ;
  return distribucion_uniforme( generador );
}

//**********************************************************************
// funciones comunes a las dos soluciones (fifo y lifo)
//----------------------------------------------------------------------

unsigned producir_dato()
{

   this_thread::sleep_for( chrono::milliseconds( aleatorio<20,100>() ));
   sem_wait( mutex_cout );
      cout << "producido: " << contador << endl << flush ;
   sem_signal( mutex_cout );
   cont_prod[contador] ++ ;
   return contador++ ;
}
//----------------------------------------------------------------------

void consumir_dato( unsigned dato )
{
   assert( dato < num_items );
   cont_cons[dato] ++ ;
   this_thread::sleep_for( chrono::milliseconds( aleatorio<20,100>() ));
   sem_wait( mutex_cout );
      cout << "                  consumido: " << dato  << endl ;
   sem_signal( mutex_cout );
}
//----------------------------------------------------------------------

void test_contadores()
{
   bool ok = true ;
   cout << "comprobando contadores ...." ;
   for( unsigned i = 0 ; i < num_items ; i++ )
   {  if ( cont_prod[i] != 1 )
      {  cout << "error: valor " << i << " producido " << cont_prod[i] << " veces." << endl ;
         ok = false ;
      }
      if ( cont_cons[i] != 1 )
      {  cout << "error: valor " << i << " consumido " << cont_cons[i] << " veces" << endl ;
         ok = false ;
      }
   }
   if (ok)
      cout << endl << flush << "solución (aparentemente) correcta." << endl << flush ;
}


//**********************************************************************
//**
//** solución FIFO
//**
//**********************************************************************

void funcion_hebra_productora(  )
{

   for( unsigned i = 0 ; i < num_items ; i++ )
   {
      int dato = producir_dato() ;
      sem_wait( puede_escribir ) ;
         buffer[primera_libre] = dato ;
         primera_libre = (primera_libre + 1) % tam_vector ;
      sem_signal( puede_leer ) ;
    }
}

//----------------------------------------------------------------------

void funcion_hebra_consumidora(  )
{

   for( unsigned i = 0 ; i < num_items ; i++ )
   {
      int dato ;
      sem_wait( puede_leer );
         dato = buffer[primera_ocupada]  ;
         primera_ocupada = (primera_ocupada + 1) % tam_vector ;
      sem_signal( puede_escribir ) ;
      consumir_dato( dato ) ;
   }
}

//----------------------------------------------------------------------

int main()
{
   cout << "---------------------------------------------------------------------" << endl
        << "Problema de 1 productor - 1 consumidor con semáforos (solución FIFO)." << endl
        << "---------------------------------------------------------------------" << endl
        << flush ;

	 thread
      hebra_productora ( funcion_hebra_productora ),
      hebra_consumidora( funcion_hebra_consumidora );

	 hebra_productora.join() ;
	 hebra_consumidora.join() ;

    test_contadores() ;
}
