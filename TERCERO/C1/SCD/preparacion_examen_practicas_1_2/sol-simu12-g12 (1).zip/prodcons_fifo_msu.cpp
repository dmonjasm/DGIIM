// -----------------------------------------------------------------------------------
//
// Prácticas SCD 20-21 GIM-GIADE (profesor: Carlos Ureña)
// Simulacro de examen (Práctica 2)
// Archivo: 'prodcons_fifo_msu.cpp'
// Monitor SU para prod-cons, con múltiples productores y consumidores
//
// Enunciado en el simulacro:
//
// 1. 
//   Sube a la tarea un archivo llamado exactamente 'prodcons_fifo_msu.cpp' con 
//   tu solución FIFO al problema de múltiples productores y consumidores, con 
//   buffer intermedio, usando un monitor SU.
//
// -----------------------------------------------------------------------------


#include <iostream>
#include <iomanip>
#include <cassert>
#include <random>
#include <thread>
#include "HoareMonitor.h"

using namespace std ;
using namespace HM ;

constexpr int
   num_items       = 15,   // número de items a producir/consumir
   num_hebras_prod = 5 ,   // número de hebras productoras (divisor de num_items)
   num_hebras_cons = 3 ,   // número de hebras consumidoras (divisor de num_items)
   num_items_prod  = num_items/num_hebras_prod, // núm. items por productor
   num_items_cons  = num_items/num_hebras_cons; // núm. items por consumidor

constexpr int
   min_ms = 5,
   max_ms = 20 ;

mutex
   mtx ;                 // mutex de escritura en pantalla
unsigned
   cont_prod[num_items] = {0}, // contadores de verificación: producidos
   cont_cons[num_items] = {0}, // contadores de verificación: consumidos
   num_vals_prod[num_hebras_prod] = {0} ; // para cada productor: número de valores producidos

//**********************************************************************
// plantilla de función para generar un entero aleatorio uniformemente
// distribuido entre dos valores enteros, ambos incluidos
// (ambos tienen que ser dos constantes, conocidas en tiempo de compilación)
//----------------------------------------------------------------------

template< int min, int max > int aleatorio()
{
  static default_random_engine generador( (random_device())() );
  static uniform_int_distribution<int> distribucion_uniforme( min, max ) ;
  return distribucion_uniforme( generador );
}

//**********************************************************************
// funciones comunes a las dos soluciones (fifo y lifo)
//----------------------------------------------------------------------

// producir un dato recibe como parámetro el núm de hebra productora

int producir_dato( int num_prod )
{
   
   this_thread::sleep_for( chrono::milliseconds( aleatorio<min_ms,max_ms>() ));
   const int valor_producido = num_prod*num_items_prod + num_vals_prod[num_prod] ;
   num_vals_prod[num_prod]++ ;
   mtx.lock();
   cout << "hebra productora " << num_prod << ", produce " << valor_producido << endl << flush ;
   mtx.unlock();
   cont_prod[valor_producido]++ ;
   return valor_producido ;
}
//----------------------------------------------------------------------

void consumir_dato( unsigned valor_consumir, int num_cons )
{
   if ( num_items <= valor_consumir )
   {
      cout << " valor a consumir === " << valor_consumir << ", num_items == " << num_items << endl ;
      assert( valor_consumir < num_items );
   }
   cont_cons[valor_consumir] ++ ;
   this_thread::sleep_for( chrono::milliseconds( aleatorio<min_ms,max_ms>() ));
   mtx.lock();
   cout << "                  hebra consumidora " << num_cons << ", consume: " << valor_consumir << endl ;
   mtx.unlock();
}
//----------------------------------------------------------------------

void test_contadores()
{
   bool ok = true ;
   cout << "comprobando contadores ...." << endl ;

   for( unsigned i = 0 ; i < num_items ; i++ )
   {
      if ( cont_prod[i] != 1 )
      {
         cout << "error: valor " << i << " producido " << cont_prod[i] << " veces." << endl ;
         ok = false ;
      }
      if ( cont_cons[i] != 1 )
      {
         cout << "error: valor " << i << " consumido " << cont_cons[i] << " veces" << endl ;
         ok = false ;
      }
   }
   if (ok)
      cout << endl << flush << "solución (aparentemente) correcta." << endl << flush ;
}

// *****************************************************************************
// clase para monitor buffer, version FIFO, semántica SC, multiples prod/cons

class ProdConsMuSU : public HoareMonitor
{
 private:
 static const int           // constantes:
   num_celdas_total = 10;   //  núm. de entradas del buffer
 int                        // variables permanentes
   buffer[num_celdas_total],//  buffer de tamaño fijo, con los datos
   primera_libre,           //  indice de celda de la próxima inserción
   primera_ocupada,         //  índice de celda de la próxima lectura
   num_celdas_ocupadas;     //  numero de valores pendientes de leer
 std::mutex
   cerrojo_monitor ;        // cerrojo del monitor
 CondVar                    // colas condicion:
   ocupadas,                //  cola donde espera el consumidor (n>0)
   libres ;                 //  cola donde espera el productor  (n<num_celdas_total)

 public:                    // constructor y métodos públicos
   ProdConsMuSU() ;             // constructor
   int  leer();                // extraer un valor (sentencia L) (consumidor)
   void escribir( int valor ); // insertar un valor (sentencia E) (productor)
} ;
// -----------------------------------------------------------------------------

ProdConsMuSU::ProdConsMuSU(  )
{
   primera_libre       = 0 ;
   primera_ocupada     = 0 ;
   num_celdas_ocupadas = 0 ;
   ocupadas            = newCondVar();
   libres              = newCondVar();
}
// -----------------------------------------------------------------------------
// función llamada por el consumidor para extraer un dato

int ProdConsMuSU::leer(  )
{
   // esperar bloqueado hasta que 0 < num_celdas_ocupadas
   if ( num_celdas_ocupadas == 0 )
      ocupadas.wait();

   //cout << "leer: ocup == " << num_celdas_ocupadas << ", total == " << num_celdas_total << endl ;
   assert( 0 < num_celdas_ocupadas  );

   // hacer la operación de lectura, actualizando estado del monitor
   const int valor = buffer[primera_ocupada] ;
   primera_ocupada = (primera_ocupada+1) % num_celdas_total ;
   num_celdas_ocupadas-- ;

   // señalar al productor que hay un hueco libre, por si está esperando
   libres.signal();

   // devolver valor
   return valor ;
}
// -----------------------------------------------------------------------------

void ProdConsMuSU::escribir( int valor )
{
   // esperar bloqueado hasta que num_celdas_ocupadas < num_celdas_total
   if ( num_celdas_ocupadas == num_celdas_total )
      libres.wait();

   //cout << "escribir: ocup == " << num_celdas_ocupadas << ", total == " << num_celdas_total << endl ;
   assert( num_celdas_ocupadas < num_celdas_total );

   // hacer la operación de inserción, actualizando estado del monitor
   buffer[primera_libre] = valor ;
   primera_libre = (primera_libre+1) % num_celdas_total ;
   num_celdas_ocupadas++ ;

   // señalar al consumidor que ya hay una celda ocupada (por si esta esperando)
   ocupadas.signal();
}
// *****************************************************************************
// funciones de hebras

void funcion_hebras_productoras( MRef<ProdConsMuSU>  monitor, int num_prod )
{
   for( unsigned i = 0 ; i < num_items_prod ; i++ )
   {
      int valor = producir_dato( num_prod ) ;
      monitor->escribir( valor );
   }
}
// -----------------------------------------------------------------------------

void funcion_hebras_consumidoras( MRef<ProdConsMuSU>  monitor, int num_cons )
{
   for( unsigned i = 0 ; i < num_items_cons ; i++ )
   {
      int valor = monitor->leer();
      consumir_dato( valor, num_cons ) ;
   }
}
// -----------------------------------------------------------------------------

int main()
{
   cout << "---------------------------------------------------------------------------------------" << endl
        << "Problema de los productores-consumidores (Monitor SU, buffer FIFO, múltiples prod/cons). " << endl
        << "--------------------------------------------------------------------------------------" << endl
        << flush ;

   // comprobar que las constantes tienen valores correctos
   assert( num_items % num_hebras_cons == 0 );
   assert( num_items % num_hebras_prod == 0 );

   // crear monitor  ('monitor' es una referencia al mismo, de tipo MRef<...>)
   MRef<ProdConsMuSU> monitor = Create<ProdConsMuSU>() ;

   // crear y lanzar las hebras
   thread hebras_prod[num_hebras_prod],
          hebras_cons[num_hebras_cons] ;
   for( unsigned i = 0 ; i < num_hebras_prod ; i++ )
      hebras_prod[i] = thread( funcion_hebras_productoras, monitor, i );
   for( unsigned i = 0 ; i < num_hebras_cons ; i++ )
      hebras_cons[i] = thread( funcion_hebras_consumidoras, monitor, i );

   // esperar a que terminen las hebras
   for( unsigned i = 0 ; i < num_hebras_prod ; i++ )
      hebras_prod[i].join();
   for( unsigned i = 0 ; i < num_hebras_cons ; i++ )
      hebras_cons[i].join();

   test_contadores() ;
}
