// -----------------------------------------------------------------------------------
//
// Prácticas SCD 20-21 GIM-GIADE (profesor: Carlos Ureña)
// Simulacro de examen (Práctica 2 - Subgrupos 1 y 2)
// Archivo: ejer2_msu.cpp
// Extensión con una hebra `contadora´  de prod-cons SU  (múltiples prod/cons)
// (se han eliminado los mensajes fuera del monitor)
//
// Enunciado en el simulacro (Grupos 1 y 2, de los viernes)
//
//  2.
//   Copia el archivo `prodcons_fifo_msu.cpp´ en otro llamado exactamente 
//   `ejer2_msu.cpp´ , y extiende la solución según se indica a aquí:
// 
//   Añade una hebra nueva llamada `contadora´, esta hebra ejecuta un bucle, en cada 
//   iteración invoca un nuevo método del monitor llamado `esperar5extraidos()´ 
//   (el bucle acaba cuando ese método devuelve un 0). Además, en cada iteración hace 
//   una espera de duración aleatoria (de duración similar a la que hacen los productores 
//   o consumidores). En dicho método, la hebra contadora da estos dos pasos:
//   
//     (1) Espera bloqueada hasta que los consumidores hayan extraído (leído) del buffer 
//         (entre todos) AL MENOS 5 nuevos valores (no espera si los consumidores ya 
//         han terminado de extraer del buffer todos los valores que había que leer 
//         durante todo el programa).
//
//     (2) Imprime un  mensaje indicando cuantos nuevos valores se han extraido
//         (en el mensaje debe de imprimir la suma de dichos nuevos valores). 
//         Por "nuevos" se entiende contados desde la última llamada este método, o 
//         desde el inicio.
//
//     (3) Devuelve el total de valores que todavía quedan por extraer entre todos 
//         los consumidores durante todo el programa.
// 
//   Ten en cuenta que los consumidores deben de llevar la cuenta de los nuevos 
//   valores extraidos y su suma, y que son responsables de despertar a la hebra 
//   contadora cuando corresponda. Ten en cuenta que el programa debe funcionar incluso 
//   si el número total de items no es múltiplo de 5.
//
// -----------------------------------------------------------------------------


#include <iostream>
#include <iomanip>
#include <cassert>
#include <random>
#include <thread>
#include <algorithm> // para poder llamar a 'std::min'
#include "HoareMonitor.h"

using namespace std ;
using namespace HM ;

constexpr unsigned
   num_items       = 36,   // número de items a producir/consumir
   num_hebras_prod = 6 ,   // número de hebras productoras (divisor de num_items)
   num_hebras_cons = 6 ,   // número de hebras consumidoras (divisor de num_items)
   num_items_prod  = num_items/num_hebras_prod, // núm. items a producir por cada productor
   num_items_cons  = num_items/num_hebras_cons; // núm. items a consumir por cada consumidor

constexpr int
   min_ms = 5,
   max_ms = 20 ;

mutex
   mtx ;                 // mutex de escritura en pantalla
unsigned
   cont_prod[num_items] = {0}, // contadores de verificación: producidos
   cont_cons[num_items] = {0}, // contadores de verificación: consumidos
   num_vals_prod[num_hebras_prod] = {0} ; // para cada productor: número de valores producidos

//**********************************************************************
// plantilla de función para generar un entero aleatorio uniformemente
// distribuido entre dos valores enteros, ambos incluidos
// (ambos tienen que ser dos constantes, conocidas en tiempo de compilación)
//----------------------------------------------------------------------

template< int min, int max > int aleatorio()
{
  static default_random_engine generador( (random_device())() );
  static uniform_int_distribution<int> distribucion_uniforme( min, max ) ;
  return distribucion_uniforme( generador );
}

//**********************************************************************
// funciones comunes a las dos soluciones (fifo y lifo)
//----------------------------------------------------------------------

// producir un dato recibe como parámetro el núm de hebra productora

int producir_dato( int num_prod )
{
   
   this_thread::sleep_for( chrono::milliseconds( aleatorio<min_ms,max_ms>() ));
   const int valor_producido = num_prod*num_items_prod + num_vals_prod[num_prod] ;
   num_vals_prod[num_prod]++ ;
   cont_prod[valor_producido]++ ;
   return valor_producido ;
}
//----------------------------------------------------------------------

void consumir_dato( unsigned valor_consumir, int num_cons )
{
   if ( num_items <= valor_consumir )
   {
      cout << " valor a consumir === " << valor_consumir << ", num_items == " << num_items << endl ;
      assert( valor_consumir < num_items );
   }
   cont_cons[valor_consumir] ++ ;
   this_thread::sleep_for( chrono::milliseconds( aleatorio<min_ms,max_ms>() ));
}
//----------------------------------------------------------------------

void test_contadores()
{
   bool ok = true ;
   cout << "comprobando contadores ...." << endl ;

   for( unsigned i = 0 ; i < num_items ; i++ )
   {
      if ( cont_prod[i] != 1 )
      {
         cout << "error: valor " << i << " producido " << cont_prod[i] << " veces." << endl ;
         ok = false ;
      }
      if ( cont_cons[i] != 1 )
      {
         cout << "error: valor " << i << " consumido " << cont_cons[i] << " veces" << endl ;
         ok = false ;
      }
   }
   if (ok)
      cout << endl << flush << "solución (aparentemente) correcta." << endl << flush ;
}

// *****************************************************************************
// clase para monitor buffer, version FIFO, semántica SC, multiples prod/cons

const unsigned           
   num_celdas_total = 10;   //  núm. de entradas del buffer
 

class ProdConsMuSU : public HoareMonitor
{
   private:

   unsigned                       //  variables permanentes
      buffer[num_celdas_total],    //  buffer de tamaño fijo, con los datos
      primera_libre       = 0,     //  indice de celda de la próxima inserción
      primera_ocupada     = 0,     //  índice de celda de la próxima lectura
      num_celdas_ocupadas = 0,     //  número de valores pendientes de leer
      num_nuevos_extr     = 0,     //  número de nuevos valores extraidos
      suma_nuevos_extr    = 0,     //  suma de los nuevos valores extraidos
      num_pendientes_extr = num_items; // número de valores pendientes de extraer entre todos los consumidores

   CondVar         // colas condicion:
      ocupadas,    // cola donde espera el consumidor (n>0)
      libres ,     // cola donde espera el productor  (n<num_celdas_total)
      contadora ;  // cola donde espera la hebra contadora

   public:                 // constructor y métodos públicos
      ProdConsMuSU() ;                // constructor
      int  leer();                    // extraer un valor (sentencia L) (consumidor)
      void escribir( int valor );     // insertar un valor (sentencia E) (productor)
      unsigned esperar5extraidos() ; // invocado por la hebra contadora

} ;
// -----------------------------------------------------------------------------

ProdConsMuSU::ProdConsMuSU(  )
{
   ocupadas = newCondVar();
   libres   = newCondVar();
   contadora = newCondVar();
}
// -----------------------------------------------------------------------------
// función llamada por el consumidor para extraer un dato

int ProdConsMuSU::leer(  )
{
   // esperar bloqueado hasta que 0 < num_celdas_ocupadas
   if ( num_celdas_ocupadas == 0 )
      ocupadas.wait();

   //cout << "leer: ocup == " << num_celdas_ocupadas << ", total == " << num_celdas_total << endl ;
   assert( 0 < num_celdas_ocupadas  );

   // hacer la operación de lectura, actualizando estado del monitor
   const int valor = buffer[primera_ocupada] ;
   primera_ocupada = (primera_ocupada+1) % num_celdas_total ;
   num_celdas_ocupadas-- ;

   
   // Contabilizar un nuevo valor extraído, actualizar suma.
   num_nuevos_extr ++ ;
   num_pendientes_extr -- ;  
   suma_nuevos_extr += valor ;

   cout << "                  Consumidor: extraído: " << valor << " (nuevos " << num_nuevos_extr << ", quedan " << num_pendientes_extr << ")" << endl ;
  
   // Habrá que despertar a la hebra 'contadora'  cuando se hayan 
   // alcanzado (al menos) 5 nuevos valores extraidos O BIEN no queden 
   // más valores por extraer
 
   if ( 5 <= num_nuevos_extr  || num_pendientes_extr == 0 )
      contadora.signal();
      
   // Señalar al productor que hay un hueco libre, por si está esperando
   libres.signal();

   // Devolver valor
   return valor ;
}
// -----------------------------------------------------------------------------

void ProdConsMuSU::escribir( int valor )
{
   // esperar bloqueado hasta que num_celdas_ocupadas < num_celdas_total
   if ( num_celdas_ocupadas == num_celdas_total )
      libres.wait();

   //cout << "escribir: ocup == " << num_celdas_ocupadas << ", total == " << num_celdas_total << endl ;
   assert( num_celdas_ocupadas < num_celdas_total );

   // hacer la operación de inserción, actualizando estado del monitor
   buffer[primera_libre] = valor ;
   primera_libre = (primera_libre+1) % num_celdas_total ;
   num_celdas_ocupadas++ ;

   cout << "insertado: " << valor << endl ;

   // señalar al consumidor que ya hay una celda ocupada (por si esta esperando)
   ocupadas.signal();
}

// -----------------------------------------------------------------------------

unsigned ProdConsMuSU::esperar5extraidos() 
{
   using namespace std ;

   // Esperar si es necesario
   if ( num_pendientes_extr > 0 && num_nuevos_extr < 5 )
      contadora.wait();
   
   cout << "                                Contadora, se han extraído " << num_nuevos_extr << " nuevos valores, la suma es " << suma_nuevos_extr << ", quedan por extraer " << num_pendientes_extr << endl ;
   
   // Poner a cero la cuenta y suma de los nuevos valores extraídos
   num_nuevos_extr = 0 ;
   suma_nuevos_extr = 0 ;

   return num_pendientes_extr ;
}

// *****************************************************************************
// funciones de hebras

void funcion_hebras_productoras( MRef<ProdConsMuSU>  monitor, int num_prod )
{
   for( unsigned i = 0 ; i < num_items_prod ; i++ )
   {
      int valor = producir_dato( num_prod ) ;
      monitor->escribir( valor );
   }
}
// -----------------------------------------------------------------------------

void funcion_hebras_consumidoras( MRef<ProdConsMuSU>  monitor, int num_cons )
{
   for( unsigned i = 0 ; i < num_items_cons ; i++ )
   {
      int valor = monitor->leer();
      consumir_dato( valor, num_cons ) ;
   }
}
// -----------------------------------------------------------------------------

void funcion_hebra_contadora( MRef<ProdConsMuSU>  monitor )
{
   while ( 0 < monitor->esperar5extraidos() ) 
      this_thread::sleep_for( chrono::milliseconds( aleatorio<min_ms,max_ms>() ));
   
}
// -----------------------------------------------------------------------------

int main()
{
   cout << "---------------------------------------------------------------------------" << endl
        << "Simulacro de examen, práctica 2, monitor SU prod-cons con hebra  'contadora' " << endl
        << "---------------------------------------------------------------------------" << endl
        << flush ;

   // comprobar que las constantes tienen valores correctos
   assert( num_items % num_hebras_cons == 0 );
   assert( num_items % num_hebras_prod == 0 );

   // crear monitor  ('monitor' es una referencia al mismo, de tipo MRef<...>)
   MRef<ProdConsMuSU> monitor = Create<ProdConsMuSU>() ;

   // crear y lanzar las hebras
   thread hebras_prod[num_hebras_prod],
          hebras_cons[num_hebras_cons],
          hebra_contadora( funcion_hebra_contadora, monitor ) ;

   for( unsigned i = 0 ; i < num_hebras_prod ; i++ )
      hebras_prod[i] = thread( funcion_hebras_productoras, monitor, i );
   for( unsigned i = 0 ; i < num_hebras_cons ; i++ )
      hebras_cons[i] = thread( funcion_hebras_consumidoras, monitor, i );

   // esperar a que terminen las hebras
   for( unsigned i = 0 ; i < num_hebras_prod ; i++ )
      hebras_prod[i].join();
   for( unsigned i = 0 ; i < num_hebras_cons ; i++ )
      hebras_cons[i].join();

   hebra_contadora.join();

   test_contadores() ;
}
