// -----------------------------------------------------------------------------------
//
// Prácticas SCD 20-21 GIM-GIADE (profesor: Carlos Ureña)
// Simulacro de examen (Práctica 2)
// Archivo: ejer3_msu.cpp
// Monitor SU para `Supermercado´ con productos, clientes y proveedores.
//
// Enunciado en el simulacro:
//
//  3.
//
//   Define en un archivo llamado `ejer3_msu.cpp´ un monitor SU llamado `Supermercado´.
//   El monitor sirve para gestionar datos de stock de `N´  productos,
//   numerados de `0´ a `N-1´ (ambos incluidos). En concreto, para cada
//   producto se guarda el número de unidades de ese producto que hay disponibles
//   a la venta en el supermercado en cada instante de tiempo (inicialmente hay 5
//   unidades de cada producto). El monitor exporta dos métodos para actualizar
//   los datos de stock:
//
//     ** Método `comprar( p, n )´: se puede invocar por una hebra para
//        gestionar la compra de `n´ unidades del producto número `p´ (ambos
//        parámetros son `unsigned´). En ese método la hebra debe esperar
//        hasta que haya al menos `n´ unidades disponibles de ese producto,
//        y después actualiza (disminuye) el stock del producto
//
//     ** Método `reponer( p, n )´: se puede invocar por una hebra para
//        gestionar la reposición de `n´ unidades del producto número `p´. En
//        ese método la hebra debe actualizar (aumentar) el stock disponible de ese
//        producto, y despertar a otras hebras que pudiesen estar esperando a
//        que haya stock de ese producto en concreto.
//
//    En el citado archivo se incluirá código para ejecutar `M´ hebras de tipo `cliente´
//    y `M´ hebras de tipo `proveedor´. Todas las hebras ejecutan un bucle infinito y
//    en cada iteración: (a) llaman a  `comprar(p,n)´ (los clientes) o `reponer(p,n)´
//    (los proveedores) y (b) esperan un tiempo aleatorio (entre 20 y 30 milisegundos).
//    Los valores que usan para `p´ (el número de producto) son aleatorios (lógicamente
//    entre `0´ y `N-1´), y los valores de `n´ también son aleatorios, siempre entre
//    10 y 20.
//
//    Ten en cuenta que una reposición puede que sea suficiente para que ninguna,
//    una o varias hebras clientes salgan de una espera y puedan comprar. Ten en cuenta
//    que una hebra cliente no debe esperar por un producto que no es el que quiere comprar.
//
// -----------------------------------------------------------------------------------



// -----------------------------------------------------------------------------------
//
//  Solucion (V1)
//  Las hebras esperando comprar se despiertan en cadena
//
// -----------------------------------------------------------------------------------

#include <iostream>
#include <iomanip>
#include <cassert>
#include <random>
#include <thread>
#include "HoareMonitor.h"

using namespace std ;
using namespace HM ;

const unsigned            // (podría usarse 'constexpr' en lugar de 'const', pero así debe compilar bien)
   num_hebras_tipo = 15,  // número de hebras de cada tipo
   num_productos   = 5;   // número de productos distintos


// ----------------------------------------------------------------------
// plantilla de función para generar un entero aleatorio uniformemente
// distribuido entre dos valores enteros, ambos incluidos
// (ambos tienen que ser dos constantes, conocidas en tiempo de compilación)
// ----------------------------------------------------------------------

template< int min, int max > int aleatorio()
{
  static default_random_engine generador( (random_device())() );
  static uniform_int_distribution<int> distribucion_uniforme( min, max ) ;
  return distribucion_uniforme( generador );
}

//----------------------------------------------------------------------
// Monitor 'Supermercado'

class Supermercado : public HoareMonitor
{
 private: // variables de instancia privadas:

   // para cada producto: número de unidades en stock (inicialmente hay 5 de cada)
   // (se debe inicializar en el constructor con un bucle)
   unsigned num_unidades_stock[ num_productos ] ;

   // para cada producto: cola de hebras cliente esperando que haya stock suficiente
   // (se debe incializar en el constructor con un bucle)
   CondVar cola_producto[ num_productos ] ;

   // método auxiliar, no imprescindible, sirve para mostrar el estado del supermercado
   void estado();

 public: // constructor y métodos públicos:

   // constructor
   Supermercado() ;

   // comprar n unidades del producto t (esperar si no hay de ese producto)
   void comprar( unsigned p, unsigned n );

   // reponer n unidades del producto t (despertar si esperan el producto)
   void reponer( unsigned p, unsigned n );
} ;
// -----------------------------------------------------------------------------

Supermercado::Supermercado(  )
{
   // Inicializar array de CondVar y stock en un bucle
   for( unsigned p = 0 ; p < num_productos ; p++ )
   {
      cola_producto[p]      = newCondVar() ;
      num_unidades_stock[p] = 5 ;
   }

}
// -----------------------------------------------------------------------------
// comprar n unidades del producto t (esperar si no hay de ese producto)


void Supermercado::comprar( unsigned p, unsigned n )
{
   // Comprobar si hay stock y esperar si no lo hay.
   // Debe ser en un bucle 'while' ya que si no puede comprar se
   // despertará cuando haya una reposición y volverá a comprobar.

   while( num_unidades_stock[p] < n )
   {
      // No hay suficiente stock como para poder comprar (se informa)
      cout << "No puedo comprar " << n << " del producto " << p << ", hay " << num_unidades_stock[p]
           << " (hebras restantes " << cola_producto[p].get_nwt() << ")" << endl ;

      // La segunda y siguientes iteraciones de este bucle se deben a una reposición del producto
      // que no es suficiente como para que esta hebra compre (esta hebra vuelve al 'wait').
      // Sin embargo, el proveedor solo despierta a una única hebra cliente cuando repone, por tanto,
      // si hay otras hebras esperando este producto, se hace aquí 'signal' para dar la oportunidad a esas hebras
      // de comprar. Esta hebra va mientras a la cola de urgentes y espera allí hasta que las
      // restantes de esta cola hayan intentado comprar (quizás algunas habrán podido hacerlo, o no).
      // Si no hay otras hebras esperando este producto, el 'signal' no hace nada.
      cola_producto[p].signal();

      // Esta hebra ha vuelto de la cola de urgentes (si ha ido), ahora se bloquea
      // (hasta que haya una futura reposición de este producto y pueda volver a comprobar).
      cola_producto[p].wait();
   }

   // Se puede comprar sin dejar el stock negativo: decrementar stock
   num_unidades_stock[p] -= n ;

   cout << endl << "Compradas " << n << " unids. de prod. " << p << ", quedan " << num_unidades_stock[p] << endl ;
   estado(); // solo para depurar

   // Si hay otras hebras esperando este producto, despertar a una de ellas
   // (en otro caso no se hace nada)
   cola_producto[p].signal();
}

// -----------------------------------------------------------------------------
// reponer n unidades del producto t (despertar si esperan el producto)

void Supermercado::reponer( unsigned p, unsigned n )
{
   // incrementar stock
   num_unidades_stock[p] += n ;

   cout << endl << "Repuestas " << n << " unids. de prod. " << p << ", ahora hay " << num_unidades_stock[p] << endl ;
   estado();

   // despertar a una de las hebras que esté esperando (esa despierta a las demás)
   cola_producto[p].signal();
}
// -----------------------------------------------------------------------------
// muestra estado del supermercado  (método auxiliar privado)

void Supermercado::estado()
{
   cout << "Estado del super (producto, stock, n. clientes) --- ... " << endl ;
   for( unsigned p = 0 ; p < num_productos ;  p++ )
      cout << p << ", " << num_unidades_stock[p] << ", " << cola_producto[p].get_nwt() << " --- " ;

   cout << endl ;
}

// *****************************************************************************
// funciones de hebras

void funcion_hebras_cliente( MRef<Supermercado> monitor, int num_cli )
{
   while( true )
   {
      unsigned
         p = aleatorio<0,num_productos-1>(),
         n = aleatorio<10,20>() ;

      monitor->comprar( p, n );
      this_thread::sleep_for( chrono::milliseconds( aleatorio<20,30>() ));
   }
}
// -----------------------------------------------------------------------------

void funcion_hebras_proveedoras( MRef<Supermercado> monitor, int num_pro )
{
   while( true )
   {
      unsigned
         p = aleatorio<0,num_productos-1>(),
         n = aleatorio<10,20>() ;

      monitor->reponer( p, n );
      this_thread::sleep_for( chrono::milliseconds( aleatorio<20,30>() ));
   }
}
// -----------------------------------------------------------------------------


int main()
{
   cout << "-----------------------------------------------------------" << endl
        << "Simulacro de examen, práctica 2, monitor SU 'Supermercado' " << endl
        << "-----------------------------------------------------------" << endl
        << flush ;

   // crear monitor  ('monitor' es una referencia al mismo, de tipo MRef<...>)
   // (usar 'auto' aquí evita tener que repetir el nombre de la clase, es equivalente a 'MRef<Supermercado>')
   auto monitor = Create<Supermercado>() ;

   // crear y lanzar las hebras
   thread hebras_cliente[ num_hebras_tipo ],
          hebras_proveedoras[ num_hebras_tipo ];

   for( unsigned i = 0 ; i < num_hebras_tipo ; i++ )
      hebras_cliente[i] = thread( funcion_hebras_cliente, monitor, i );

   for( unsigned i = 0 ; i < num_hebras_tipo ; i++ )
      hebras_proveedoras[i] = thread( funcion_hebras_proveedoras, monitor, i );

   // esperar a que terminen las hebras

   for( unsigned i = 0 ; i < num_hebras_tipo ; i++ )
      hebras_cliente[i].join();

   for( unsigned i = 0 ; i < num_hebras_tipo ; i++ )
      hebras_proveedoras[i].join();
}
