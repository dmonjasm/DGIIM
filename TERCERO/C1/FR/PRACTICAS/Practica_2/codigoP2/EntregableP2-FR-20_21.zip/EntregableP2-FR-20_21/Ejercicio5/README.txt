David Suarez González
Daniel Monjas Miguélez

Se recomienda ejecutar ServidorCine y ClienteCine como proyectos de netbeans,
Al estar hecho con netbeans los códigos están en la carpeta src dentro de cada uno de los correspondientes proyectos(ServidorCine y ClienteCine).
En la carpeta data de ServidorCine se encuentras los archivos cartelera.txt y usuarios.txt, el primero contiene las películas para ver y es indispensable y el segunda contendrá 
los usuarios.
