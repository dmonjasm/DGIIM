/**
 * @file main.cpp
 * @author MP
 */
#include <iostream>
#include <cstring>
#include <string>
#include "Kmer.h"
#include "SecuenciasKmer.h"

using namespace std;

void mensajeError() {
    cerr << "ERROR en la llamada" << endl;
    cerr << "   kmer [-i <fichero-entrada>] [-o <fichero-salida>]"<<endl;
    exit(1); 
}
 
int main(int narg, char *args[]) {
    SecuenciasKmer seq;
    string i="data/pepe.kmer", o="data/pepe.kmer";
    bool funciona=true;
    
    if (narg != 1 && narg != 3 && narg != 5)
        mensajeError();
    ///...
    else{
        if(narg == 3){
            if(strcmp(args[1],"-i")==0){ /// if (strcmp(args[1],"-i")== 0)
                funciona=seq.loadFichero(args[2]);
                
                if(funciona){
                    cout << "Comprimiendo secuencia kmers..." << endl;
                    seq.zipSecuenciasKmer();
                    cout << "Ordenando secuencia de kmers..." << endl;
                    seq.ordenar();
                    
                    seq.writeSecuenciasKmer();
                }
                    
                else
                    cerr << "ERROR: en el fichero "<< args[2] << endl;               
                }                
            
            else{
                if(strcmp(args[1],"-o")==0){
                    seq.readSecuenciasKmer();
                    
                    cout << "Comprimiendo secuencia kmers..." << endl;
                    seq.zipSecuenciasKmer();
                    cout << "Ordenando secuencia de kmers..." << endl;
                    seq.ordenar();
                    
                    funciona=seq.saveFichero(args[2]);
                
                    
                    if(!funciona)
                        cerr << "ERROR: en el fichero " << args[2] << endl;
                }
            }
        }
        
        else{
            if(narg==1){
                seq.readSecuenciasKmer();
                
                cout << "Comprimiendo secuencia de kmers..." << endl;
                seq.zipSecuenciasKmer();
                cout << "Ordenando secuencia de kmers..." << endl;
                seq.ordenar();
                
                seq.writeSecuenciasKmer();
            }         
            else{
                if((strcmp(args[1],"-i")==0)&&(strcmp(args[3],"-o")==0)){
                    funciona=seq.loadFichero(args[2]);
                    
                    if(funciona){
                        cout << "Comprimiendo secuencia de kmers..." << endl;
                        seq.zipSecuenciasKmer();
                        cout << "Ordenando secuencia de kmers..." << endl;
                        seq.ordenar();
                    
                        funciona=seq.saveFichero(args[4]);
                        
                        if(!funciona)
                            cerr << "ERROR: en el fichero " << args[4] << endl;
                    }
                    
                    else
                        cerr << "ERROR: en el fichero " << args[2] << endl;
                }
                
                else{
                    if((strcmp(args[1],"-o")==0)&&(strcmp(args[3],"-i")==0)){
                        funciona=seq.loadFichero(args[4]);
                       
                        if(funciona){
                            cout << "Comprimiendo secuencia de kmers..." << endl;
                            seq.zipSecuenciasKmer();
                            cout << "Ordenando secuencia de kmers..." << endl;
                            seq.ordenar();
                        
                            funciona=seq.saveFichero(args[2]);
                            
                            if(!funciona)
                                cerr << "ERROR: en el fichero " << args[2] << endl;
                        }
                        
                        else
                            cerr << "ERROR: en el fichero " << args[4] << endl;
                    }
                    
                    else{
                        mensajeError();
                    }
                }
                
            }
        }
    }
    return 0;    
}

        

