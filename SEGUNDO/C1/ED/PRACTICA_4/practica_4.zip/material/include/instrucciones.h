#ifndef INSTRUCCIONES_H
#define INSTRUCCIONES_H

#include "arbolbinario.h"
#include "acciones.h"
#include "ingredientes.h"
#include <string>
#include <list>
#include <stack>

class instrucciones{
    private:
        ArbolBinario<string> datos;
        acciones acc;
        vector<string> nombre_ingredientes;

    public:
        instrucciones(){};
        instrucciones(const instrucciones & copia){
            datos=copia.datos;
            acc=copia.acc;
        };
        void setAcciones(const acciones & set){acc=set;};
        void setIngredientes(const vector<string> & nombres){nombre_ingredientes=nombres;};
        int obtenerOperando(const string & accion);
        bool ValidarIngredientes(const string & ingrediente);
        pair<bool,int> ValidarAcciones(const string & accion);
        void EstablecerAcciones(const string & accion);
        void EstablecerIngrediente(const string & ingrediente);
        void Escribe(std::ostream & os, const ArbolBinario<string> & salida);
        void Lee(std::istream & is,instrucciones & entrada );
        ArbolBinario<string> & getDatos(){return this->datos;};
        friend std::ostream & operator<<(std::ostream & os, instrucciones & salida);
        friend std::istream & operator>>(std::istream & is, instrucciones & entrada);
        
        


};

std::ostream & operator<<(std::ostream & os, instrucciones & salida);
std::istream & operator>>(std::istream & is,instrucciones & entrada);

#endif
