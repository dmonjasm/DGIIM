#include "receta.h"
#include "recetas.h"
#include "acciones.h"
#include "arbolbinario.h"
#include "ingrediente.h"
#include "ingredientes.h"
#include "instrucciones.h"
#include <iostream>
#include <map>
#include <vector>
#include <fstream>
#include <string>


using namespace std;

void error(){
    cout << "Modo de ejecución: <programa> <archivo_acciones> <archivo_recetas> <archivo_ingredientes> <pathname_instrucciones>" << endl;
    exit(-1);
}

int main(int argc, char * argv[]){

    if(argc < 5){
        error();
    }

    acciones all_acciones;
    ingredientes all_ingredientes;
    recetas all_recetas;
    instrucciones all_instrucciones;
    string nf=argv[1];
    ifstream entrada(nf);
    string path_instrucciones=argv[4];

    if(!entrada){
        cerr << "error al abrir el archivo de acciones" << endl;
        exit(-1);
    }

    entrada >> all_acciones;

    entrada.close();
    nf=argv[2];

    entrada.open(nf);
    if(!entrada){
        cerr << "error al abrir el archivo de recetas" << endl;
        exit(-1);
    }

    entrada >> all_recetas;
    entrada.close();

    nf=argv[3];

    entrada.open(nf);

    if(!entrada){
        cerr << "error al abrir el archivo de ingredientes" << endl;
        exit(-1);
    }

    entrada >> all_ingredientes;

    entrada.close();

    recetas::iterator it=all_recetas.begin();

    for(;it != all_recetas.end(); ++it){
        cout << "CODE: " << (*it).getCode() << "\tNOMBRE: " << (*it).getNombre() << "\tPLATO: " << (*it).getPlato() << endl;
    }

    string codigo;
    receta buscada;

    cout << "Introduzca el código de una receta: " << endl;
    cin >> codigo;

    buscada=all_recetas[codigo];
    buscada.setNutricion(all_ingredientes);

    cout << "CODIGO:" << codigo << " RECETA:" << buscada.getNombre() << " PLATO:" << buscada.getPlato() << endl;
    cout << "Ingredientes:" << endl;
    for(receta::iterator it=buscada.begin(); it != buscada.end(); ++it){
        cout << "\t" << (*it).first << " " << (*it).second << endl;
    }

    cout << "Información nutricional: " << endl;
    cout << "Calorias:" << buscada.getCalorias() << endl;
    cout << "Hidratos de Carbono:" << buscada.getHc() << endl;
    cout << "Grasas:" << buscada.getGrasas() << endl;
    cout << "Proteinas:" << buscada.getProteinas() << endl;
    cout << "Fibra:" << buscada.getFibra() << endl;

    path_instrucciones=path_instrucciones + codigo + "m.txt";
    cout << "El pathname del archivo de instrucciones es -> " << path_instrucciones << endl;

    nf=path_instrucciones;
    entrada.open(path_instrucciones);

    if(!entrada){
        cerr << "Error al abrir el archivo con las instrucciones" << endl;
    }

    all_instrucciones.setAcciones(all_acciones);
    all_instrucciones.setIngredientes(all_ingredientes.getNombres());
    
    entrada >> all_instrucciones;

    entrada.close();

    cout << all_instrucciones << endl;

return 0;
}