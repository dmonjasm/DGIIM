#include <stack>
#include <iostream>
#include "cola.h"

using namespace std;

int main(int argc, char** argv) {
    cola<int> cola_inicial;
    
    cola_inicial.push_back(1);
    cola_inicial.pop_front();
    if(cola_inicial.empty())
	cout << "VACIA" << endl;

    cola_inicial.push_back(8);
    cola_inicial.push_back(5);
    cola_inicial.push_back(2);
    cola_inicial.push_back(3);
    cola_inicial.push_back(2);
    cola_inicial.push_back(3);
    
    
    for(int i=0; !cola_inicial.empty() ;i++){
        cout << cola_inicial.front() << endl;
        cola_inicial.pop_front();
    }
    
    if(cola_inicial.empty())
        cout << "VACÍA" << endl;
    

    cola_inicial.push_back(6);
    cola_inicial.push_back(1);
    cola_inicial.push_back(2);
    cola_inicial.push_back(3);
    
    cola<int> cambia;
    
    cambia.push_back(4);
    cambia.push_back(9);
    
    cola_inicial.swap(cambia);

    for(int i=0; !cola_inicial.empty() ; i++){
        cout << "COLA_1 TRAS EL CAMBIO " <<cola_inicial.front() << endl;
        cola_inicial.pop_front();
    }

    for(int i=0;!cambia.empty(); i++){
        cout << "COLA_2 TRAS EL CAMBIO " << cambia.front() << endl;
        cambia.pop_front();
    }
    
    if(cola_inicial.empty()&&cambia.empty())
        cout << "AMBAS PILAS ESTAN VACIAS" << endl;

    
    return 0;
}

