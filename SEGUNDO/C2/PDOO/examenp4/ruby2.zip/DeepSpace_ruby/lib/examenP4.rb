# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative 'FaultySpaceCity'

class ExamenP4
  def initialize
    
  end
  
  array_ciudades = Array.new
  
  2.times {array_ciudades.push(Deepspace::SpaceStation.new("Daniel", Deepspace::SuppliesPackage.new(1,10,1)))}
  
  for i in array_ciudades
    i.receiveHangar(Deepspace::Hangar.new(4))
    2.times {i.receiveWeapon(Deepspace::Weapon.new("Láser infinito",Deepspace::WeaponType::LASER,100))}
    2.times {i.mountWeapon(0)}
  end
  
  ciudad_espacial = Deepspace::SpaceCity.new(array_ciudades.at(0),Array.new(array_ciudades))   
  
  ciudad_espacial.fire
  
  puts ciudad_espacial.getUIversion.to_s
end
