# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative 'Damage'
require_relative 'WeaponType'
require_relative 'Weapon'
require_relative 'ShieldBooster'
class Examen
  def initialize
    
  end
  
  def self.principal
    array_tipos=Array.new
    
    array_tipos.push(Deepspace::WeaponType::LASER)
    array_tipos.push(Deepspace::WeaponType::PLASMA)
    array_tipos.push(Deepspace::WeaponType::LASER)
    array_tipos.push(Deepspace::WeaponType::MISSILE)
    
    objeto_damage=Deepspace::Damage.newSpecificWeapons(array_tipos,4)
    
    puts objeto_damage.to_s
    
    array_armas=Array.new
    array_escudos = Array.new
    
    array_armas.push(Deepspace::Weapon.new("Arma_Daniel",Deepspace::WeaponType::MISSILE, 10))
    array_armas.push(Deepspace::Weapon.new("Arma_Daniel", Deepspace::WeaponType::LASER, 10))
    array_escudos.push(Deepspace::ShieldBooster.new("Escudo Daniel", 10,10))
    
    objeto_damage=objeto_damage.adjust(array_armas, array_escudos)
    
    puts objeto_damage.to_s
    
  end
  
  Examen.principal
end
