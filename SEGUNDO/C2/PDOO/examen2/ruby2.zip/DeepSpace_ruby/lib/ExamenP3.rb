# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.


#En el ejercicio 1 he creado dos métodos para el dado, uno que devuelve true si los sobrevivientes de la nave enemiga roban items, el otro decidirá cuantos items roban, siempre teniendo cuidado 
# de no superar el número máximo de cada item que va recibir la nave, entre ,1 y el tope que se le pase. Creo una instancia de dado en el método setLoot que es el que asigna el loot a la nave espacial.
#Creo también dos variables locales, una robo que guarda si los enemigos roban o no y otro elementos_robados que almacenará cuantos items se roba de cada tipo en cada momento.
#Tras esto con el dado llamo al método que decide si los enemigos roban con la probabilidad 0.3, si no roban setLoot se ejecutará normal, si roban, entonces,
#antes de asignar cada tipo de items se almacena en la variable local elements el número de elementos de un tipo que se van a dar a la nave, entonces si elements < 4
# se limita el posible numero de elementos robados a elements, en caso contrario se podrán robar hasta 4 elementos.
#Esto se va a realizar antes de asignar cada tipo de item (weapons, shieldbooster, suppliespackage), una vez decidido el número de elementos a robar, se entra en el bucle for
# en este habrá un if(robo == false) si robo es false entonces se ejecuta con normalidad, en caso contrario, el bucle se ejecuta solamente hasta (elements - elementos_robados), que por como 
# hemos definido siempre es positivo o igual a 0, y a partir de ahí las iteraciones no harán nada. Esto se repite en todos lo bucles que asignan items a la nave espacial. Por tanto se le asignarán
# los elementos que se asignarían normalemente menos el numero de elementos que se hayan robados.
#Para este examen he añadido a dice un nuevo atributo de instancia prob_rob que es la probabilidad con la que se roba, y dos metodos de instancia que deciden si se roba y cuantos elementos se roban
require_relative 'Damage'
require_relative 'WeaponType'
require_relative 'Weapon'
require_relative 'ShieldBooster'

class Examen
  def initialize
    
  end
  
  def self.principal
    array_tipos=Array.new
    
    array_tipos.push(Deepspace::WeaponType::LASER)
    array_tipos.push(Deepspace::WeaponType::PLASMA)
    array_tipos.push(Deepspace::WeaponType::LASER)
    array_tipos.push(Deepspace::WeaponType::MISSILE)
    
    objeto_damage=Deepspace::Damage.newSpecificWeapons(array_tipos,4)
    
    puts objeto_damage.to_s
    
    array_armas=Array.new
    array_escudos = Array.new
    
    array_armas.push(Deepspace::Weapon.new("Arma_Daniel",Deepspace::WeaponType::MISSILE, 10))
    array_armas.push(Deepspace::Weapon.new("Arma_Daniel", Deepspace::WeaponType::LASER, 10))
    array_escudos.push(Deepspace::ShieldBooster.new("Escudo Daniel", 10,10))
    
    objeto_damage=objeto_damage.adjust(array_armas, array_escudos)
    
    puts objeto_damage.to_s
    
  end
  
  Examen.principal
end
